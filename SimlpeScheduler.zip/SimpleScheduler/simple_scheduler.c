#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#define MAX_JOBS 100
typedef struct Job{
    pid_t pid;
    int isCompleted;
    time_t startTime;
    time_t completionTime;
    int executionTime; 
    int waitTime;      
} Job;
Job jobQueue[MAX_JOBS];
int jobCount = 0;
int currentJobIndex = 0;
int NCPU;
int TSLICE;
void addedjob(int executionTime);
void removecomjob();
void scheduleJob();
void handeltime(int sig);
void stopscheduler(int sig);
void jobsummary();
// Add a job to the queue
void addedjob(int executionTime){
    if (jobCount >= MAX_JOBS){
        fprintf(stderr, "Job queue is full, cannot add more jobs.\n");
        return;
    }
    pid_t pid = fork();
    if (pid == 0) { // Child process
        // Simulate job execution
        sleep(executionTime);
        exit(0); // Exit after execution
    } else if (pid > 0){ // Parent process
        jobQueue[jobCount].pid = pid;
        jobQueue[jobCount].isCompleted = 0;
        jobQueue[jobCount].startTime = time(NULL);
        jobQueue[jobCount].executionTime = executionTime; // Set execution time
        jobQueue[jobCount].waitTime = 0; // Initialize wait time
        jobCount++;
        printf("Job added with PID %d and execution time %d seconds.\n", pid, executionTime);
    } else {
        perror("Failed to fork for job");
    }
}
// Remove completed jobs from the job queue
void removecomjob(){
    for (int i=0;i<jobCount;i++){
        if (jobQueue[i].isCompleted){
            printf("Job with PID %d completed in %.0f seconds.\n", jobQueue[i].pid,difftime(jobQueue[i].completionTime, jobQueue[i].startTime));
            // Shift jobs in the queue to fill the gap
            for (int j=i;j<jobCount-1;j++){
                jobQueue[j]=jobQueue[j+1];
            }
            jobCount--;
            i--; // Adjust index after removal
        }
    }
}
// Function to schedule jobs using Round Robin
void scheduleJob(){
    if (jobCount==0){
        return; // No jobs to schedule
    }
    for (int i=0;i<NCPU;i++){
        if (currentJobIndex >= jobCount){
            currentJobIndex = 0;
        }
        if (jobQueue[currentJobIndex].isCompleted == 0){
            printf("Scheduling job with PID %d for execution...\n", jobQueue[currentJobIndex].pid);
            jobQueue[currentJobIndex].waitTime += TSLICE; // Increment wait time before scheduling
            sleep(TSLICE); // Simulate time slice
            jobQueue[currentJobIndex].completionTime = time(NULL);
            jobQueue[currentJobIndex].isCompleted = 1; // Mark as completed
        }
        currentJobIndex++; // Move to the next job
        removecomjob(); // Clean up completed jobs
    }
}
// Signal handler for time slice end
void handeltime(int sig){
    scheduleJob();
}
// Signal handler for termination signal
void stopscheduler(int sig){
    jobsummary();
    exit(0);
}
// Function to print job summary
void jobsummary(){
    printf("Job Summary:\n");
    printf("%-6s | %-15s | %-15s | %-10s | %-10s\n", "PID", "Start Time", "Completion Time", "Wait Time", "Total Time");
    for (int i=0;i<jobCount;i++){
        if (jobQueue[i].isCompleted) {
            printf("%-6d | %-15s | %-15s | %-10d | %-10.0f\n", jobQueue[i].pid,ctime(&jobQueue[i].startTime),ctime(&jobQueue[i].completionTime),jobQueue[i].waitTime,difftime(jobQueue[i].completionTime, jobQueue[i].startTime) + jobQueue[i].waitTime);
        }
    }
}
int main(int argc, char *argv[]){
    if (argc != 3){
        fprintf(stderr, "Usage: %s <ncpu> <timeslice>\n", argv[0]);
        return 1;
    }
    NCPU = atoi(argv[1]);
    TSLICE = atoi(argv[2]);
    // Set up signal handlers
    signal(SIGALRM, handeltime);
    signal(SIGINT, stopscheduler); // Handle termination gracefully
    // Main scheduling loop
    while (1) {
        pause();
    }
    return 0;
}
