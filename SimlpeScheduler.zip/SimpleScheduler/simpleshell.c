#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>
#include <time.h>

#define MAX_JOBS 100
#define MAX_ARGS 10
int NCPU;
int TSLICE;
// Structure to store job information
typedef struct Job{
    pid_t pid;
    char name[256];
    time_t startTime;
    time_t endTime;
    int isCompleted;
    double waitTime; // Track wait time
} Job;
Job jobs[MAX_JOBS];
int jobCount = 0;
pid_t schedule_pid; 

// Function to start the SimpleScheduler as a daemon process
void startscheduler(int ncpu,int tslice){
    schedule_pid = fork();
    if (schedule_pid < 0) {
        perror("Failed to fork SimpleScheduler");
        exit(EXIT_FAILURE);
    } else if (schedule_pid==0){
        char ncpu_str[10];
        char tslice_str[10];
        sprintf(ncpu_str, "%d", ncpu);
        sprintf(tslice_str, "%d", tslice);
        execlp("./simple_scheduler", "simple_scheduler", ncpu_str, tslice_str, (char *)NULL);
        perror("Failed to start SimpleScheduler"); // Only reached if execlp fails
        exit(EXIT_FAILURE);
    } else {
        printf("SimpleScheduler started with PID %d\n", schedule_pid);
    }
}
// Function to handle the "submit" command and create a new job
void submitjob(const char *program, const char *arg){
    if (jobCount >= MAX_JOBS){
        printf("Job limit reached.\n");
        return;
    }
    pid_t job_pid = fork();
    if (job_pid < 0){
        perror("Failed to fork job");
        return;
    } else if (job_pid == 0){
        // Prepare arguments for exec
        char *args[MAX_ARGS];
        args[0]=(char *)program; // The program name
        args[1]=(char *)arg; // The first argument
        args[2]=NULL; // Null-terminate the array
        execvp(args[0], args);  
        perror("Failed to start job");  
        exit(EXIT_FAILURE);
    } else{
        jobs[jobCount].pid=job_pid;
        snprintf(jobs[jobCount].name, sizeof(jobs[jobCount].name), "%s", program);
        jobs[jobCount].startTime=time(NULL);
        jobs[jobCount].isCompleted =0;
        jobs[jobCount].waitTime=0; 
        jobCount++;
        printf("Job submitted with PID %d\n", job_pid);
    }
}
// Function to clean up and exit
void cleanandexit(){
    printf("Terminating SimpleShell...\n");
    // Wait for each job to complete
    for (int i=0;i<jobCount;i++){
        int status;
        pid_t result;
        printf("Waiting for job %d with PID %d...\n", i + 1, jobs[i].pid);
        while ((result=waitpid(jobs[i].pid, &status, WNOHANG))==0){
            sleep(1);  // Pause to avoid tight looping
            jobs[i].waitTime += 1; // Increase wait time during wait
            printf("Still waiting for job %d with PID %d... Wait Time: %.2f seconds\n", i + 1, jobs[i].pid, jobs[i].waitTime);
        }
        if (result==jobs[i].pid){
            jobs[i].endTime=time(NULL);
            jobs[i].isCompleted=1;
            printf("Job %d with PID %d has completed.\n", i + 1, jobs[i].pid);
        } else {
            printf("Error waiting for job %d with PID %d.\n", i + 1, jobs[i].pid);
        }
    }
    // Print job statistics
    printf("Job Summary:\n");
    printf("%-15s | %-6s | %-15s | %-10s | %-10s\n", "Name", "PID", "Completion Time", "Wait Time", "Total Time");
    printf("-----------------------------------------------------------\n");
    for (int i=0;i<jobCount;i++){
        double completionTime = difftime(jobs[i].endTime, jobs[i].startTime) * 1000; // ms
        double totalTime = completionTime + jobs[i].waitTime * 1000; // Convert wait time to ms
        printf("%-15s | %-6d | %-15.2f ms | %-10.2f ms | %-10.2f ms\n",
               jobs[i].name, jobs[i].pid,
               completionTime,
               jobs[i].waitTime * 1000, // Convert to milliseconds
               totalTime);
    }
    // Terminate the SimpleScheduler
    printf("Sending SIGTERM to SimpleScheduler PID %d...\n", schedule_pid);
    kill(schedule_pid,SIGTERM);
    sleep(1); // Give time for termination
    char ps_command[50];
    sprintf(ps_command, "ps -p %d > /dev/null",schedule_pid);
    if(system(ps_command) != 0) {
        printf("SimpleScheduler with PID %d has terminated.\n", schedule_pid);
    }
    else{
        printf("Warning: SimpleScheduler PID %d still active.\n", schedule_pid);
    }
    exit(0);
}
int main(int argc, char *argv[]){
    if (argc < 3){
        fprintf(stderr, "Usage: %s <ncpu> <timeslice>\n", argv[0]);
        return 1;
    }
    int ncpu = atoi(argv[1]);
    int tslice = atoi(argv[2]);
    printf("SimpleShell initialized with %d CPUs and %d ms time slice.\n", ncpu, tslice);
    NCPU = ncpu; 
    TSLICE = tslice;
    startscheduler(ncpu,tslice);
    char command[100];
    while (1) {
        printf("SimpleShell$ ");
        if (fgets(command,sizeof(command),stdin)==NULL){
            break;
        }
        command[strcspn(command, "\n")]=0;
        if (strncmp(command,"submit",6)==0){
            char *program = strtok(command + 7," "); // Get the program path
            char *arg = strtok(NULL, " "); // Get the argument (if any)
            if (program != NULL) {
                submitjob
            (program, arg); // Now call with both program and argument
            } else {
                printf("No program specified.\n");
            }
        }else if(strcmp(command, "exit") == 0) {
            cleanandexit();
        }else{
            printf("Unknown command. Use 'submit <program>' or 'exit'.\n");
        }
    }
    return 0;
}
