#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
int main(int argc,char *argv[]){
    if (argc!=2){
        fprintf(stderr, "Usage: %s <duration>\n", argv[0]);
        return 1;
    }
    int duration=atoi(argv[1]);
    printf("Hello, World! Sleeping for %d seconds...\n", duration);
    sleep(duration);
    printf("Finished sleeping for %d seconds.\n", duration);
    return 0;
}
