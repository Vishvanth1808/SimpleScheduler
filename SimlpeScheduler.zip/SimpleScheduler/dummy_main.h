#ifndef DUMMY_MAIN_H
#define DUMMY_MAIN_H
#include <stdio.h>
#include <signal.h>
#include <unistd.h>
int dummy_main(int argc, char **argv);
int main(int argc, char **argv) {
    // Block until SIGCONT is received from the scheduler
    printf("Process %d waiting for SIGCONT to start execution.\n", getpid());
    pause(); // Waiting for SIGCONT to start
    int ret = dummy_main(argc, argv);
    // Notify completion
    printf("Process %d completed execution.\n", getpid());
    return ret;
}
#define main dummy_main

#endif /* DUMMY_MAIN_H */
